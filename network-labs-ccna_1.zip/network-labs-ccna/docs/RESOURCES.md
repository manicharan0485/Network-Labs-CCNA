# Free CCNA 200-301 Study Resources

## Video Courses

| Resource | URL | Notes |
|----------|-----|-------|
| **Jeremy's IT Lab** | youtube.com/@JeremysITLab | Best free CCNA course — full 200-301 coverage |
| Cisco NetAcad | netacad.com | Free with registration — official Cisco content |
| David Bombal | youtube.com/@davidbombal | Packet Tracer labs, networking concepts |
| NetworkChuck | youtube.com/@NetworkChuck | Beginner-friendly, practical demos |

## Practice Labs

| Tool | Download | Cost |
|------|----------|------|
| **Cisco Packet Tracer** | netacad.com (free login) | Free |
| GNS3 | gns3.com | Free (needs Cisco IOS images) |
| EVE-NG Community | eve-ng.net | Free community edition |

## Practice Questions

| Site | URL | Notes |
|------|-----|-------|
| ExamTopics | examtopics.com/exams/cisco/200-301 | Free community Q&A |
| Boson (paid) | boson.com | Best practice exams ($99) |
| Cisco Learning Network | learningnetwork.cisco.com | Official Cisco forums |

## Reference Materials

| Resource | URL |
|----------|-----|
| Cisco IOS Command Reference | cisco.com/c/en/us/support/ios-nx-os-software |
| RFC Index | rfc-editor.org |
| Subnetting Practice | subnettingpractice.com |
| CCNA Study Guide (free PDF) | Available on learningnetwork.cisco.com |

## Wireshark

| Resource | URL |
|----------|-----|
| Wireshark Download | wireshark.org |
| Sample Captures | wiki.wireshark.org/SampleCaptures |
| Display Filter Reference | wiki.wireshark.org/DisplayFilters |

## Security Labs (Phase 3)

| Resource | URL | Notes |
|----------|-----|-------|
| TryHackMe | tryhackme.com | Pre-Security & Network rooms |
| Metasploit Unleashed | metasploitunleashed.com | Free Metasploit course |
| HackTheBox Academy | academy.hackthebox.com | Networking fundamentals path |

## CCNA Exam Info

- **Exam code:** 200-301
- **Duration:** 120 minutes
- **Questions:** ~100 (MCQ, drag-drop, simulation)
- **Passing score:** ~825/1000
- **Cost:** ~$330 USD (varies by country)
- **Register:** certiport.com or vue.com
- **Validity:** 3 years

## Study Schedule (18 Weeks)

```
Week 1-2:   Network fundamentals, OSI, TCP/IP, subnetting
Week 3-4:   Ethernet, switching basics, Cisco IOS CLI
Week 5-6:   VLANs, trunking, inter-VLAN routing
Week 7-8:   STP, EtherChannel, Layer 2 security
Week 9:     Review Phase 1-2 + practice labs
Week 10-11: Static routing, OSPF single area
Week 12:    OSPF multi-area, EIGRP basics
Week 13:    ACLs, NAT/PAT
Week 14:    DHCP, DNS, NTP, SSH hardening
Week 15:    WAN technologies, VPN concepts
Week 16:    QoS, network automation, Python basics
Week 17-18: Practice exams, weak areas review
```

## Daily Routine
```
Daytime:    Job applications and IT work
21:00–22:30: CCNA study — video → notes → Packet Tracer lab
Weekend:    Longer labs, practice exams, Wireshark analysis
```
